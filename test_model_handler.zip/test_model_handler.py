"""Positive and negative test cases for model_handler.py"""
import glob
import json
import logging
import os
import re
from collections import namedtuple

import numpy as np
import pandas as pd
from sklearn.metrics.pairwise import cosine_similarity
import joblib
from transformers import DistilBertTokenizerFast, DistilBertModel, pipeline

from opensearchpy import OpenSearch, RequestsHttpConnection
from requests_aws4auth import AWS4Auth
import boto3

import pytest
from docker.Inference.model_handler import ModelHandler, handle

_service = ModelHandler()

# test initialize
@pytest.mark.parametrize('result', [None, 0])
def test_initialize(result):
    init = _service.initialize
    assert init() == result

# test inference
@pytest.mark.parametrize('result', [dict, int])
def test_inference(result, model_input='here is a sample sentence'):
    inf = _service.inference(_service.initialize, model_input)
    assert type(inf) == result

# test postprocess
test_dict = {"a": 2, "b": 2, "c": 3}
res = [json.dumps({"result": test_dict})]
@pytest.mark.parametrize('post', [res, None])
def test_postprocess(post):
    js = _service.postprocess(test_dict)
    assert js == post

# test handle
test_data = [{'head': 'head string', 'body': 'body string'}]
@pytest.mark.parametrize('result', [list, None])
def test_handle(result):
    out = _service.handle(test_data)
    assert type(out) == result

# test handle service
@pytest.mark.parametrize('result', [(None, list), (list, None)])
def test_handle_(result):
    data = test_data
    if data is None:
        assert handle(data) == result[0]
    else:
        assert type(handle(data)) == result[1]

